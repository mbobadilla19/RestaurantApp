package parent_class.subclass;
import parent_class.Food;

/*UML Diagram for the subclass */
/** 
 * @author Miguel Bobadilla
 * ---------------------
 *        Subclass:    |
 *       MainCourse    |
 * ---------------------
 * Fields:             |
 *                     |
 * - category: String  |
 * --------------------------------------------------------------
 * Methods:                                                     |
 *                                                              |
 * +MainCourse (name: String, price: String, category : String) |
 * +getCategory() : String                                      |
 * +setCategory(category : String) : void                       |                              |
 * +toString(): String                                          |
 * --------------------------------------------------------------
 */


// Subclass representing a main course
public class MainCourse extends Food 
{
    private String category;

    /**
     * Constructor for MainCourse class.
     * @param name     the name of the main course
     * @param price    the price of the main course
     * @param category the category of the main course
     */
    public MainCourse(String name, String price, String category) 
    {
        super(name, price);
        this.category = category;
    }

    /**
     * Get the category of the main course.
     * @return the category of the main course
     */
    public String getCategory() 
    {
        return category;
    }

    /**
     * Set the category of the main course.
     * @param category the category of the main course
     */
    public void setCategory(String category) 
    {
        this.category = category;
    }


    /**
     * Get a string representation of the main course.
     * @return a string representation of the main course
     */
    public String toString() 
    {
        return super.toString() + " (" + category + ")";
    }
}

