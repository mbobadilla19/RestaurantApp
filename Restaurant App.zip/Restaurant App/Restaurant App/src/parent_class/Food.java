package parent_class;
public class Food 

/*UML Diagram */
/**
 * @author Miguel Bobadilla
 * ---------------------
 *        Food          |
 * ---------------------
 * Fields:
 * 
 * - name: String      |
 * - price: String     |
 * -----------------------------------
 * Methods:
 * 
 * +Food(name: String, price: String) |
 * +getName(): String                 |
 * +setName(name: String): void       |
 * +getPrice(): String                |
 * +setPrice(price: String): void     |
 * +toString(): String                |
 * -----------------------------------
 */
{
    //  Private variables
    private String name;
    private String price;


    /**
     * Constructs a new Food object with the specified name and price.
     * @param name  the name of the food item
     * @param price the price of the food item
     */
    public Food(String name, String price) 
    {
        this.name = name;
        this.price = price;
    }

    /**
     * Returns the name of the food item.
     * @return the name of the food item
     */
    public String getName() 
    {
        return name;
    }

    /**
     * Sets the name of the food item.
     * @param name the name of the food item
     */
    public void setName(String name) 
    {
        this.name = name;
    }

    /**
     * Returns the price of the food item.
     * @return the price of the food item
     */
    public String getPrice() 
    {
        return price;
    }

    /**
     * Sets the price of the food item.
     * @param price the price of the food item
     */
    public void setPrice(String price) 
    {
        this.price = price;
    }

    /**
     * Returns a string representation of the Food object.
     * @return a string representation of the Food object
     */
    @Override
    public String toString() {
        return "Food name: " + name + ", price: $" + price + "]";
    }
}


