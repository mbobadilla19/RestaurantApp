import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController 
{
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    //  Login button
    @FXML
    private Button login;

     //  Variables from scene builder
    @FXML
    private TextField password;

    @FXML
    private TextField username;

    //  Login button function that checks for login into
    @FXML
    void loginButton(ActionEvent event) throws IOException 
    {
        checkLogin(event);
    }

    /**
     * Check login function that 
     * @param event
     * @throws IOException
     */
    private void checkLogin(ActionEvent event) throws IOException 
    {
        //  Use of conditionals to check if info is correct to be able to log in
        if (username.getText().equals("username") && password.getText().equals("123")) //   Log in page example, given username and password
        {
            //  Launch Dashboard after info was correct
            root = FXMLLoader.load(getClass().getResource("fxml/Dashboard.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } 
        else
        {
            //  Resets
            checkLogin(event);
        }
    }

    @FXML
    void initialize() 
    {
        assert login != null : "fx:id=\"login\" was not injected: check your FXML file 'LoginPage.fxml'.";
        assert password != null : "fx:id=\"password\" was not injected: check your FXML file 'LoginPage.fxml'.";
        assert username != null : "fx:id=\"username\" was not injected: check your FXML file 'LoginPage.fxml'.";
    }
}
