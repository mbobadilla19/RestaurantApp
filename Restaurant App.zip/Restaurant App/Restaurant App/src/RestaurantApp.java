/**
 * @author Miguel Bobadilla
 * Professor Rodrigues
 * CIS-166-M01 Java fund.
 * Final Project
 * Description: it is a restaurant app with features-
 * and interactions
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import parent_class.*;  //  Importing class from folder
import parent_class.subclass.MainCourse; // Importing subclass from folder to demostrate the use of inheritance

public class RestaurantApp extends Application 
{
    @Override
    public void start(Stage primaryStage) 
    {
        //Switch
        boolean mySwitch = true;
        
        // Generate the menu (Example) using inheritance to demostrate standard 6
        Food dish1 = new MainCourse("Ceviche", "$99.99", "Lunch");
        
        //  While loop to load fxml files
        while(mySwitch)
        {
            try 
            {
                // Load the FXML file
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("fxml/LoginPage.fxml"));
                Parent root = (Parent) fxmlLoader.load();
                
                // Get the controller instance
                LoginController LoginController = fxmlLoader.getController();

                // Set the scene for the primary stage
                Scene scene = new Scene(root);
                primaryStage.setTitle("Log-in Page");
                primaryStage.setScene(scene);
                primaryStage.show();
                
            } catch (Exception e) 
            {
                e.printStackTrace();
            }  
            //  Dashboard Page
            try 
            {
                // Load the FXML file
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("fxml/Dashboard.fxml"));
                Parent root = (Parent) fxmlLoader.load();
                
                // Get the controller instance
                DashboardController dashboardController = fxmlLoader.getController();

                // Override variable foodName (first plate) in fxml main dashboard as an example using inheritance
                dashboardController.getFoodName().setText(dish1.getName());
                dashboardController.getFoodPrice().setText(dish1.getPrice());

            } catch (Exception e) 
            {
                e.printStackTrace();
            }  
            mySwitch = false;
        }
        //  Load controllers & FXML files
      
        
    }
        
    public static void main(String[] args) 
    {
        launch(args);
    }
}
/*
 * Pseudocode:
 * 
 * 1. The program imports all the necessary classes and subclasses
 * 2. The program defines the main class (RestaurantApp) 
 * 3. The program generates an object of the subclass MainCourse
 * 4. The program loads the fxml files by creating objects of their controller
 * 5. The program launches the code
 * 6. The program then prompts the user to log in using username and password 
 * 7. If login is successful, the program will load to the dashboard.fxml file
 * 8. Otherwise, the program will remain static
 */